package KModbus


val MODBUS_VERSION            = 1


val TCP_SERIAL_INDEX           =  0
val TCP_HEADER_LEN             =  6 //RAW_BYTES = HEADER_LEN + PKG_LEN
val TCP_PKG_LEN_INDEX          =  5 //ALWAYS for all cmd
val TCP_STATION_NUMB_INDEX     =  6
val TCP_PKG_CMD_INDEX          =  7
val TCP_RSP_RD_DATA_EXTRA_BYTE =  3
val TCP_REQ_TRG_ADDR_INDEX     =  8
val TCP_REQ_TRG_NUMB_INDEX     = 10
val TCP_REQ_SINGLE_DATA_INDEX  = 10
val TCP_REQ_TRG_DATA_INDEX     = 13
val TCP_RSP_DATA_INDEX         =  9
val TCP_RSP_REQ_SHORT_PKG_LEN  =  6
val TCP_REQ_WRP_EXTRA_BYTES    =  7


val MD_SHORT_CMD_LEN           = 0x08
val MD_DEV_ADDR_LEN            = 0x08
val MD_0X10_EXTRA_BYTE         = 0x09
val MD_0X03_EXTRA_BYTE         = 0x05
val MD_UART_MAX_LEN            = 0x100
val MD_RSP_DATA_INDEX          = 0x03          //Slave 0x03 data start
val MD_DEV_ADDR_INDEX          = 0x00
val MD_DEV_CMD_INDEX           = 0x01 
val MD_CMD_INDEX               = 0x01
val MD_RSP_BYTE_LEN_INDEX      = 0x02          //回复的字节数所在
val MD_RSP_EXTRA_BYTE          = 0x05
val MD_STATION_INDEX           = 0x00
val MD_0X06_TRG_ADDR_INDEX     = 2
val MD_0X06_TRG_DATA_INDEX     = 4
val MD_TRG_ADDR_INDEX          = 2
val MD_0X10_TRG_NUMB_INDEX     = 4
val MD_0X10_TRG_BCNT_INDEX     = 6
val MD_0X10_TRG_DATA_INDEX     = 7
val MD_0X05_TRG_ADDR_INDEX     = 2
val MD_0X05_TRG_DATA_INDEX     = 4
val MD_0X0F_TRG_ADDR_INDEX     = 2
val MD_0X0F_TRG_NUMB_INDEX     = 4
val MD_0X0F_TRG_BCNT_INDEX     = 6
val MD_0X0F_TRG_DATA_INDEX     = 7
val MD_REQ_BYTE_LEN_INDEX      = 6          //批量写的字节数所在位置
val MD_REQ_EXTRA_BYTE          = 9
val MD_READ_TRG_ADDR_INDEX     = 2
val MD_READ_TRG_NUMB_INDEX     = 4
val MD_READ_RSP_DATA_INDEX     = 3


val MD_0X10_TRG_ADDR_INDEX     = 0x02
val MD_0X10_TRG_LEN_INDEX      = 0x04
val MD_0X10_TRG_NUM_INDEX      = 0x06
val MD_0X03_TRG_ADDR_INDEX     = 0x02
val MD_0X03_RSP_NUM_INDEX      = 0x02
val MD_0X03_TRG_LEN_INDEX      = 0x04
val MD_0X03_TRG_NUM_INDEX      = 0x06
val MD_DEV_RSP_DATA_LEN_INDEX  = 0x02
val MD_MST_RSP_DATA_INDEX      = 0x03
val MD_MST_DATA_INDEX          = 0x07//Master 0x10 data start
val MD_MST_DATA_BIT_INDEX      = 0x04//Master 0x10 data start

enum class MdCmdEnum{
    MD_CMD_COIL_RD, //coil read    region 1
    MD_CMD_WRC    , //coil write   region 1
    MD_CMD_WRCP   , //write coils  region 1
    MD_CMD_BIT_RD , //bit read     region 2
    MD_CMD_RDO    , //word read    region 4
    MD_CMD_RD     , //read  word   holding    region 3
    MD_CMD_WR     , //write word   region 3
    MD_CMD_WRP    , //write some   region 3
    MD_CMD_ERR    ;


    companion object{
        fun parse(code: Byte):MdCmdEnum{
            return when(code.toInt()){
                0x01   -> MD_CMD_COIL_RD
                0x05   -> MD_CMD_WRC
                0x0F   -> MD_CMD_WRCP
                0x02   -> MD_CMD_BIT_RD
                0x04   -> MD_CMD_RDO
                0x03   -> MD_CMD_RD
                0x06   -> MD_CMD_WR
                0x10   -> MD_CMD_WRP
                else   -> MD_CMD_ERR
            }
        }
    }
}


fun MdCmdEnum.Code(): Int{
    return when(this){
        MdCmdEnum.MD_CMD_COIL_RD  ->  0x01
        MdCmdEnum.MD_CMD_WRC      ->  0x05
        MdCmdEnum.MD_CMD_WRCP     ->  0x0F
        MdCmdEnum.MD_CMD_BIT_RD   ->  0x02
        MdCmdEnum.MD_CMD_RDO      ->  0x04
        MdCmdEnum.MD_CMD_RD       ->  0x03
        MdCmdEnum.MD_CMD_WR       ->  0x06
        MdCmdEnum.MD_CMD_WRP      ->  0x10
        else                      ->  0xFF
    }

}

val MdSupportCmd = listOf(
        0x01,
        0x05,
        0x0F,
        0x02,
        0x04,
        0x03,
        0x06,
        0x10
)

enum class MdRegion{
    MD_REGION_1XXXX,
    MD_REGION_2XXXX,
    MD_REGION_3XXXX,
    MD_REGION_4XXXX,
}


fun MdRegion.Code(): Int{
    return when(this){
        MdRegion.MD_REGION_1XXXX ->  0x01
        MdRegion.MD_REGION_2XXXX ->  0x02
        MdRegion.MD_REGION_3XXXX ->  0x03
        MdRegion.MD_REGION_4XXXX ->  0x04 //holding
    }
}

fun MdCmdEnum.toRegion(): MdRegion{
    return when(this){
        MdCmdEnum.MD_CMD_COIL_RD -> MdRegion.MD_REGION_1XXXX
        MdCmdEnum.MD_CMD_WRC     -> MdRegion.MD_REGION_1XXXX
        MdCmdEnum.MD_CMD_WRCP    -> MdRegion.MD_REGION_1XXXX
        MdCmdEnum.MD_CMD_BIT_RD  -> MdRegion.MD_REGION_2XXXX
        MdCmdEnum.MD_CMD_RDO     -> MdRegion.MD_REGION_3XXXX
        MdCmdEnum.MD_CMD_RD      -> MdRegion.MD_REGION_4XXXX
        MdCmdEnum.MD_CMD_WR      -> MdRegion.MD_REGION_4XXXX
        MdCmdEnum.MD_CMD_WRP     -> MdRegion.MD_REGION_4XXXX
        MdCmdEnum.MD_CMD_ERR     -> MdRegion.MD_REGION_4XXXX
    }
}

enum class MdRspCode
{
    MD_ERR_OK,
    MD_CMD_ERR,
    MD_CRC_ERR,
    MD_FIND_OK,
    MD_POLL_OK,
    MD_LEN_ERR,
    MD_POLL_ERR,
    MD_FIND_NEXT,
    MD_NULL_ERROR,
    MD_CMD_LEN_ERR,
    MD_MEM_REQ_ERR,
    MD_TRG_LEN_ERR,
    MD_CMD_ADDR_ERR,
    MD_CMD_TYPE_ERR,
    MD_DEV_ADDR_ERR,
    MD_TRG_ADDR_ERR,
    MD_ERR_RSP_ID_ERR,
    MD_ERR_RSP_LEN_ERR,
    MD_BUS_DEV_FIND_OK,
    MD_TRG_LEN_LMT_ERR,
    MD_MEM_POLL_NUM_ERR,
    MD_NULL_POINTER_ERR,
    MD_SPE_POLL_IN_DEAL,
    MD_NOT_MASTER_ERROR,
    MD_NOTHING_ENABLE_ERR,
    MD_READ_TOTAL_LEN_ERR,
    MD_WRITE_TOTAL_LEN_ERR,
    MD_ERR_RSP_DATA_LEN_ERR,
    MD_NULL_POINTER_BINDDEV,
    MD_NULL_POINTER_BINDPCB,
    MD_CMD_RESPONSE_FLAG_ERR,
    MD_READING_MAX_LEN_EXCEED,
}











