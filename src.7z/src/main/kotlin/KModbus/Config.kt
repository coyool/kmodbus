package KModbus


val USING_REMAP_MULTI_TO_ONE  = 1       //把多个站号按照1:1000的方式平分到各个站号上面
val USING_REMAP_MULTI_DEVIDE  = 1000    //把多个站号按照1:1000的方式平分到各个站号上面
val USING_REMAP_GHOST_STATION = 247     //把这个站号的平摊





















